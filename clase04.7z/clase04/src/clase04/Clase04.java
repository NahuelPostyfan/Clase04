package clase04;
public class Clase04 {
    public static void main(String[] args) {
    String nombre = "Nahuel";
    System.out.println(nombre);
    
    //pasar texto a mayúscula
    System.out.println(nombre.toUpperCase());
    String nombre2 = "Leal";
    nombre2 = nombre2.toUpperCase();
    System.out.println(nombre2);
    
    //pasar texto a minúscula
    String nombre3 = "ALEXIS";
    nombre3 = nombre3.toLowerCase();
    System.out.println(nombre3);
    
    String palabra1= "cuesta";
    String palabra2= "subir";
    String palabra3= "la";
    String palabra4= "a";
    String palabra5= "e";
    String palabra6= "l";
    String palabra7= "v";
    String palabra8= "s";
    String palabra9= "n";
    String palabra10= "d";
    String palabra11= "y";
    String palabra12= "medio";
    String palabra13= ",";
    
        System.out.println(palabra4.toUpperCase() + " " + palabra1 + " " + palabra6+palabra5 + " " + palabra1 + " " + palabra2);
        System.out.println(palabra3 + " " + palabra1 + " " + palabra11 + " " + palabra5 + palabra9+" "+palabra12+" "+palabra10+palabra5);
        System.out.println(palabra3+" "+palabra1+palabra13+" "+ palabra7+palabra4+ " "+ palabra11+ " " + palabra8+palabra5+" "+palabra4+palabra1);        
    }
    
}
